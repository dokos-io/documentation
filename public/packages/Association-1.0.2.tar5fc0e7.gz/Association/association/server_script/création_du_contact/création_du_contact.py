doc = frappe.form_dict.doc

def postprocess(source, target):
	target.append("email_ids", {"email_id": doc.email, "is_primary": 1})

	if doc.get("phone") or doc.get("is_primary_phone"):
		target.append(
			"phone_nos",
			{"phone": doc.get("phone") or doc.get("is_primary_phone"), "is_primary_phone": 1},
		)

	if doc.get("mobile_no") or doc.get("is_primary_mobile_no"):
		target.append(
			"phone_nos", {"phone": doc.get("mobile_no") or doc.get("is_primary_mobile_no"), "is_primary_mobile_no": 1}
		)

	target.append("links", {"link_doctype": "Customer", "link_name": doc.customer})

mapped_doc = frappe.get_mapped_doc(
	doc.doctype,
	doc.name,
	{
		doc.doctype: {
			"doctype": "Contact",
			"field_no_map": ["status"],
		},
	},
	postprocess=postprocess,
	ignore_permissions=True,
)
mapped_doc.insert(ignore_permissions=True)

frappe.flags.contact = mapped_doc.name