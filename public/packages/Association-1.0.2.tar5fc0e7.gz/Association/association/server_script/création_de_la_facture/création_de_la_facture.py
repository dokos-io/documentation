doc = frappe.form_dict.doc

si = frappe.new_doc("Sales Invoice")
si.flags.ignore_permissions = True
si.company = frappe.db.get_default("Company")
si.customer = doc.customer
si.append(
	"items",
	{
		"item_code": "Imprimante 3D", # Indiquer le code article à facturer
		"description": "Adhésion à l'association",
		"qty": 1,
		"rate": doc.amount,
	},
)
si.run_method("set_missing_values")
si.run_method("calculate_taxes_and_totals")

si.insert()
si.submit()

frappe.flags.invoice = si.name

payment_request = frappe.new_doc("Payment Request")
payment_request.reference_doctype = si.doctype
payment_request.reference_name = si.name
payment_request.grand_total = si.grand_total
payment_request.flags.ignore_permissions = True
payment_request.insert()
payment_request.submit()

payment_request.set_as_paid()