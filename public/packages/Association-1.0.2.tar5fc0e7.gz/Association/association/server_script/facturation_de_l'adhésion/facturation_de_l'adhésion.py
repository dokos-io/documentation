
doc.date_de_fin = frappe.utils.add_days(frappe.utils.add_years(doc.date_de_debut, 1), -1)

has_customer = False
if frappe.db.exists("Contact", {"email_id": doc.email}):
    contact = frappe.get_doc("Contact", {"email_id": doc.email})
    doc.contact = contact.name
    doc.user = contact.user
    has_customer = contact.get("links", filters={"link_doctype": "Customer"})
    if has_customer:
        doc.customer = contact.get("links", filters={"link_doctype": "Customer"})[0].get("link_name")


if not doc.customer:
    doc.customer = run_script('Création du client', doc=doc).get("customer")

if not doc.contact:
    doc.contact = run_script('Création du contact', doc=doc).get("contact")
elif has_customer:
    contact.append("links", {
        "link_doctype": "Customer",
        "link_name": doc.customer
    })
    contact.flags.ignore_permissions = True
    contact.save()

if doc.address_line1 and doc.city:
    doc.address = run_script("Création de l'adresse", doc=doc).get("address")

if not doc.user:
    doc.user = run_script("Création de l'utilisateur", doc=doc).get("user")

if doc.amount and doc.status == "Paid":
    doc.invoice = run_script("Création de la facture", doc=doc).get("invoice")