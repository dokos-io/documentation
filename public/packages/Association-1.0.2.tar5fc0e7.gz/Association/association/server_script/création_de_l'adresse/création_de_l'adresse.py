doc = frappe.form_dict.doc

def set_missing_values(source, target):
	target.append("links", {"link_doctype": "Customer", "link_name": doc.customer})
	target.is_primary_address = 1

mapped_doc = frappe.get_mapped_doc(
	doc.doctype,
	doc.name,
	{
		doc.doctype: {
			"doctype": "Address",
			"field_no_map": ["status"],
		},
	},
	postprocess=set_missing_values,
	ignore_permissions=True,
)

mapped_doc.flags.ignore_permissions = True
mapped_doc.insert()

frappe.flags.address = mapped_doc.name