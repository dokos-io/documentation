try:
    doc = frappe.form_dict.doc
    
    contact = frappe.get_doc("Contact", doc.contact)
    
    frappe.flags.mute_messages = True
    user = frappe.get_doc(
    	{
    		"doctype": "User",
    		"first_name": contact.first_name,
    		"last_name": contact.last_name,
    		"email": contact.email_id,
    		"user_type": "Website User",
    		"send_welcome_email": 1,
    	}
    ).insert(ignore_permissions=True, ignore_if_duplicate=True)
    frappe.flags.mute_messages = False
    
    frappe.flags.user = user.name
except Exception:
    doc.log_error("Erreur lors de la création de l'utilisateur")
