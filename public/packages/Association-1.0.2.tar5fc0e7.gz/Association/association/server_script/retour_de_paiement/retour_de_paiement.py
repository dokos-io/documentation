data = frappe.form_dict
if data.get("reference_doctype") == "Adhesion" and data.get("reference_docname"):
    doc = frappe.get_doc(data.get("reference_doctype"), data.get("reference_docname"))
    doc.reference_no = data.get("orderId") or data.get("checkoutIntentId")
    if data.get("code") == "succeeded":
        doc.status = "Paid"
    else:
        doc.status = "Error"

doc.flags.ignore_permissions = True
doc.submit()
