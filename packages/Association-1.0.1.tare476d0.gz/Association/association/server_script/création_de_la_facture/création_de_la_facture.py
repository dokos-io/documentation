doc = frappe.form_dict.doc

si = frappe.new_doc("Sales Invoice")
si.flags.ignore_permissions = True
si.company = frappe.db.get_default("Company")
si.customer = doc.customer
si.append(
	"items",
	{
		"item_code": "", # Indiquer le code article à facturer
		"description": "Adhésion à l'association",
		"qty": 1,
		"rate": doc.amount,
	},
)
si.run_method("set_missing_values")
si.run_method("calculate_taxes_and_totals")

si.insert()
si.submit()

frappe.flags.invoice = si.name

payment_entry = frappe.call("erpnext.accounts.doctype.payment_entry.payment_entry.get_payment_entry", dt="Sales Invoice", dn=si.name, party_amount=doc.amount, ignore_permissions=False)
payment_entry.reference_no = doc.reference_no
payment_entry.reference_date = frappe.utils.nowdate()
payment_entry.flags.ignore_permissions=True
payment_entry.insert()
payment_entry.submit()