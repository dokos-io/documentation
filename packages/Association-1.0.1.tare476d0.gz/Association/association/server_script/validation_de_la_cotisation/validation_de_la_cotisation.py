if doc.amount < 1:
    frappe.throw("Le montant minimum est de 1€")