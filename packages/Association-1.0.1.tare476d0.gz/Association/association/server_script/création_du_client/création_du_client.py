doc = frappe.form_dict.doc

def set_missing_values(source, target):
	target.customer_type = "Individual"
	target.customer_name = doc.first_name + " " + doc.last_name
	target.customer_group = frappe.db.get_default("Customer Group")
	target.territory = frappe.db.get_default("Territory")

mapped_doc = frappe.get_mapped_doc(
	doc.doctype,
	doc.name,
	{
		doc.doctype: {
			"doctype": "Customer",
			"field_no_map": ["status"],
		},
	},
	None,
	set_missing_values,
	ignore_permissions=True,
)

mapped_doc.insert(ignore_permissions=True)

frappe.flags.customer = mapped_doc.name